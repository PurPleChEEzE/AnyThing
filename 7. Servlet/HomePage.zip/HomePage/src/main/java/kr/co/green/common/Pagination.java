package kr.co.green.common;

public class Pagination {
	public static PageInfo getPageInfo(int listCount, int cpage, int pageLimit, int boardLimit) {
//		ex) listCount : 101, boardLimit : 5
//		double -> 소수점까지 구하기 위해 사용
//		math.ceil -> 소수점 올림 처리 
		int maxPage = (int) (Math.ceil((double) listCount / boardLimit));

		int startPage = (cpage - 1) / pageLimit * pageLimit + 1;

		int endPage = startPage + pageLimit - 1;

		if (endPage > maxPage) {
			endPage = maxPage;
		}

		int offset = (cpage - 1) * boardLimit;

		return new PageInfo(listCount, cpage, pageLimit, boardLimit, maxPage, startPage, endPage, offset);

	}
}
