package kr.co.green.board.model.service;

import java.util.ArrayList;

import kr.co.green.board.model.dto.BoardDto;
import kr.co.green.board.model.dto.FreeDtoImpl;
import kr.co.green.common.PageInfo;

public interface BoardService {
	
	public ArrayList<FreeDtoImpl> getList(PageInfo pi, String category, String searchText);
	
	//전체 게시글 수 
	public int getListCount(String category, String searchText);
	//글등록
	
	
	
	public int enroll(FreeDtoImpl bdto);
	
	//글내용
	public FreeDtoImpl getDetail(int boardNo);
	//글수정
	
	public FreeDtoImpl getEditForm(int boardNo);
	
	
	public int setEdit(FreeDtoImpl freeDto);
	//글삭제


	 public int setDelete(int boardNo);
	
}
